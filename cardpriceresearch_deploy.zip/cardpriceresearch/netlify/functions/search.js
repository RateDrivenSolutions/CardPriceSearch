exports.handler = async function (event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
  if (!ANTHROPIC_API_KEY) {
    return { statusCode: 500, body: JSON.stringify({ error: "API key not configured" }) };
  }

  // ── Rate limiting (simple IP-based, 20 requests per hour) ──────────────────
  // For production, swap this with Redis/Upstash for persistence across instances
  const ip = event.headers["x-forwarded-for"] || "unknown";
  // Netlify functions are stateless — add Upstash Redis for real rate limiting
  // This is a placeholder reminder

  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON" }) };
  }

  const { prompt, sport, card, condition, market } = body;

  if (!card || card.trim().length < 2) {
    return { statusCode: 400, body: JSON.stringify({ error: "Card name too short" }) };
  }

  // ── Build the prompt ────────────────────────────────────────────────────────
  const systemPrompt = `You are an expert trading card price researcher with deep knowledge of Pokemon TCG, NFL, NBA, WWE, and MLB card markets. 
You provide accurate, up-to-date price information based on recent sales data from eBay, TCGPlayer, Amazon, and PriceCharting.
Always respond in valid JSON only — no markdown, no backticks, no preamble.`;

  const userPrompt = `Research current ${sport || "trading"} card prices for: "${card}".
Show prices for ${condition || "all conditions (PSA 10, PSA 9, Near Mint, Lightly Played, Heavily Played)"} on ${market || "the general collector market"}.

Use web search to find the most current prices. Respond ONLY with this JSON structure:
{
  "card_name": "Full official card name",
  "set": "Set name and year",
  "rarity": "Card rarity",
  "sport": "Sport/game type",
  "trend": "up|down|stable",
  "trend_reason": "One sentence explaining the trend",
  "prices": [
    { "condition": "PSA 10 Gem Mint", "value": "$X,XXX", "note": "brief context", "highlight": false },
    { "condition": "PSA 9 Mint", "value": "$XXX", "note": "brief context", "highlight": false },
    { "condition": "Near Mint (raw)", "value": "$XX–$XX", "note": "brief context", "highlight": true },
    { "condition": "Lightly Played", "value": "$XX", "note": "brief context", "highlight": false },
    { "condition": "Heavily Played", "value": "$XX", "note": "brief context", "highlight": false }
  ],
  "buy_links": {
    "ebay": "https://www.ebay.com/sch/i.html?_nkw=CARD+NAME+encoded",
    "tcgplayer": "https://www.tcgplayer.com/search/pokemon/product?q=CARD+NAME",
    "pricecharting": "https://www.pricecharting.com/search-products?type=prices&q=CARD+NAME",
    "amazon": "https://www.amazon.com/s?k=CARD+NAME+pokemon+card"
  },
  "analysis": "2-3 sentence market analysis",
  "buy_tip": "One actionable buy or sell tip",
  "data_confidence": "high|medium|low"
}

Fill in real search URLs with the actual card name URL-encoded. Set highlight:true on the most commonly traded condition.`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-haiku-4-5-20251001",
        max_tokens: 1200,
        tools: [{ type: "web_search_20250305", name: "web_search" }],
        system: systemPrompt,
        messages: [{ role: "user", content: userPrompt }],
      }),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      console.error("Anthropic error:", err);
      return {
        statusCode: response.status,
        body: JSON.stringify({ error: err.error?.message || "API error" }),
      };
    }

    const data = await response.json();
    const textBlocks = data.content
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("");

    let parsed;
    try {
      const cleaned = textBlocks.replace(/```json|```/g, "").trim();
      const match = cleaned.match(/\{[\s\S]*\}/);
      parsed = JSON.parse(match ? match[0] : cleaned);
    } catch {
      return {
        statusCode: 500,
        body: JSON.stringify({ error: "Could not parse response", raw: textBlocks }),
      };
    }

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify(parsed),
    };
  } catch (err) {
    console.error("Function error:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message || "Unknown error" }),
    };
  }
};
